
//app module
import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {HttpModule} from "@angular/http";

import {FormsModule} from "@angular/forms";

import {RouterModule} from "@angular/router";

import {AppComponent} from "./app.component";

import {HomeComponent} from "./home.component";

import {ContactComponent} from "./contact.component";

import {ProductListComponent} from "./product/product-list.component";

import {ProductWidgetComponent} from "./product/product-widget.component";

import {ByYearPipe} from "./product/product.pipes";

import * as config from "./app.config";

import {appRouting} from "./app.routing";

import {LocationStrategy, HashLocationStrategy, PathLocationStrategy}
from "@angular/common";


import {ProductEditComponent} from "./product/product-edit.component";


@NgModule({
    imports: [
        BrowserModule,
        HttpModule,
        FormsModule,
        RouterModule,
        appRouting
    ],
    
    declarations: [
        AppComponent,
        HomeComponent ,
        ContactComponent,
        ProductListComponent,
        ProductWidgetComponent,
        ByYearPipe,
        ProductEditComponent
    ],

    bootstrap: [
        AppComponent
    ],

    providers: [
        {
            provide: 'apiEndPoint',
            useValue: config.API_END_POINT
        },

        { //enables #Hash URL
            provide: LocationStrategy,
            useClass: HashLocationStrategy
        }
    ]
})
export class AppModule {

}