import {Component} from "@angular/core";

@Component({
    selector: 'angular-app',
    template: `
        <h2>First Angular2 App</h2>

        <nav >
            <a routerLink="/" >Home</a>
            <a routerLink="/products">Products</a>
            <a routerLink="/contact">Contact</a>
        </nav>


        <router-outlet>
        </router-outlet>

        <!--<home></home>

        <product-list>

        </product-list>

        <contact></contact>
        
        -->
    `
})
export class AppComponent {

}