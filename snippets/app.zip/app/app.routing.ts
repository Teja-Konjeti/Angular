import {RouterModule, Routes} from "@angular/router";

import {HomeComponent} from "./home.component";
import {ContactComponent} from "./contact.component";

import {ProductListComponent} from "./product/product-list.component";

import {ProductEditComponent} from "./product/product-edit.component";

const routes:Routes = [
    {
        path: '', //localhost:3000
        component: HomeComponent
    },

    {
        path: 'contact', //localhost:3000/contact
        component: ContactComponent
    },

    {
        path: 'products',
        component: ProductListComponent
    },

    {
        path: 'products/edit/:id',
        component: ProductEditComponent
    }
]

export const appRouting = RouterModule.forRoot(routes);

