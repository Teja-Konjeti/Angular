import {Component, Input, Output, EventEmitter}
 from "@angular/core";

import {Product} from "./product";

@Component({
    selector: 'product-widget',
    template: `
            <p>Name : 
            
            <a routerLink="/products/edit/{{product.id}}" >

            {{product?.name | uppercase}}
            
            </a>
            
            </p>

            <p>Year : {{product?.year}}</p>

            <button (click)="addToCart()">Add</button>
    `
})
export class ProductWidgetComponent {
    @Input()
    product: Product;

    
    @Output()
    addToCartEvent:EventEmitter<Product> = new EventEmitter<Product>();
    


    addToCart() {
        console.log("add to cart clicked");

        this.addToCartEvent.emit(this.product);
    }


}