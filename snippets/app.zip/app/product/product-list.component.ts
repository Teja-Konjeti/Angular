import {Component, OnInit} from "@angular/core";

import {ProductService} from "./product.service";

import {Product} from "./product";

import "rxjs/Rx";

@Component({
    selector: 'product-list',
    templateUrl: "app/product/product-list.html" 
})
export class ProductListComponent implements OnInit {
    products: Array<Product> ;

    year: number = 2010;
     
    constructor(private productService: ProductService) {

    }

    ngOnInit() {
         this.productService.getProducts()
         .subscribe ( ( data: Product[]) => {
             this.products = data;
         })
    }

    addToShoppingCart(product: Product) {
        console.log("adding product to cart", product);
    }
}