import {Component, OnInit} from "@angular/core";

import {ProductService} from "./product.service";

//TODO: products/edit/1
//TODO: products/create

import {ActivatedRoute, Router} from "@angular/router";

@Component({
    templateUrl: 'app/product/product-edit.html'
})
export class ProductEditComponent implements OnInit {
    product: any = {};

    constructor(private productService:ProductService, 
                private route: ActivatedRoute,
                private router: Router
    ) {
    }

    ngOnInit() {
        console.log("edit init");
        
        
        this.route.params.forEach( (params: any) => {
            let id = params["id"];

            console.log(id);

            this.productService.getProduct(id)
            .then( (data: any) => {
                this.product = data;
            })


        })
        
    }

    //TODO: implement save, create product use cases
    //TODO: implement delete example

    ngOnDestroy() {
            console.log("edit destroy");
    }

    saveProduct(){
        
    }
}