import {Injectable, Inject} from "@angular/core";

import {Http, Response} from "@angular/http";

import {Product} from "./product";
import "rxjs/Rx";

@Injectable()
export class ProductService {
   
    constructor(private http: Http,
                @Inject("apiEndPoint") private apiEndPoint: string
    ) {
        console.log("created product service  ", apiEndPoint);
         
    }

    getProducts() {
        console.log("getting products from service");
         return this.http.get( this.apiEndPoint + "/api/products")
         .map ( (response : Response) => response.json())
    }
}