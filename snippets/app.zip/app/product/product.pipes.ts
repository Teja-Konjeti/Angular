import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'byYear'
})
export class ByYearPipe implements PipeTransform {
    transform(inputs: any[], year?: string | number) {
        if (!inputs)
            return;

        if (!year) {
            return inputs;
        }

        let results: any[] = [];

        for(let product of inputs) {
            if (product.year == year) {
                results.push(product);
            }
        }

        return results;
    }
}