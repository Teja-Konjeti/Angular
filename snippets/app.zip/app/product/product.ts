export class Product {
    name : string;
    year: number;
    id : number;
    brandId : number;
}
