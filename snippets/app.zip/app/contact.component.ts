import {Component} from "@angular/core";

@Component({
    selector: 'contact',
    template: `
        <h2>{{title}}</h2>
    `
})
export class ContactComponent {
    title: string = "Contact";
}