import {Component} from "@angular/core";

@Component({
    selector: 'home',
    template: `
        <h2>Home </h2>
    `
})
export class HomeComponent {
    
}